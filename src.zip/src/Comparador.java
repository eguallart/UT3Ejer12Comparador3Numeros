public class Comparador {

    public int mayorDeTres(int a, int b, int c) {
        int mayor = a; //establecemos que A es el mayor

        if (b > mayor) {
            mayor = b; //mayor si 'b' es mayor
        }

        if (c > mayor) {
            mayor = c; //mayor si 'c' es mayor
        }

        return mayor;

    }
}