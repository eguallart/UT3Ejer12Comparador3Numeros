public class Main {
    public static void main(String[] args){

        Comparador comparador = new Comparador();

        int a = 50;
        int b = 10;
        int c = 3;

        int resultado = comparador.mayorDeTres(a, b, c);
        System.out.println("El mayor de los tres es: " + resultado);

    }
}
